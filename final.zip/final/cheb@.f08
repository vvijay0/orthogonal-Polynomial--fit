! ! working :12/09/2023 DIRECT, cheb, nearly equal step. ( monomial  WORKING  )
	Module FixPrecision        ! To Fix_precision
	! Kind values available
	! Integer:p=1,2,4,8
	! Real:p=4,8,15
	! Complex:-1xp;p=4,8,15
	! logical:-1xp,p=1,4
	implicit none
	CHARACTER(10),public   :: IN
	integer, parameter,public    :: I1=SELECTED_INT_KIND(1)
	integer, parameter,public    :: i2=SELECTED_INT_KIND(2)
	integer, parameter,public    :: i4=SELECTED_INT_KIND(4)
	integer, parameter,public    :: i8=SELECTED_INT_KIND(8)

	integer, parameter,public    :: R4 =SELECTED_REAL_KIND(4)
	integer, parameter ,public   :: R8 =SELECTED_REAL_KIND(8)
	integer, parameter,public    :: R15=SELECTED_REAL_KIND(15)
	integer, parameter,public    :: qp = selected_real_kind(33)
	!integer, parameter          :: qp = selected_real_kind(p=30)
	!integer, parameter          :: qp = selected_real_kind (32)
	! examples
	!integer(i4) :: ND
	!real(R15) :: X
	!real(R15), parameter :: pi
	!pi=2._dp*asin(1._r15)
	end Module FixPrecision

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	module DataSeize    ! find data seize and get data
	use FixPrecision
	implicit none
	INTEGER(i8), public :: DS
	INTEGER(i8), public :: NPS,ic
	contains
	subroutine DataS (IN)
	implicit none
	CHARACTER(10) :: in
	CHARACTER :: ss
	INTEGER :: rstat
	real(R4)    :: x1
	WRITE(*,'(''    Input file Name    = '')')
	READ(*,*)in
    	OPEN(UNIT=2,FILE=in,STATUS='UNKNOWN')
	WRITE(*,'(''     Nos Lines  considered as Comment   :- '',i2)')
	read(*,*)Ic
	rstat = 0
	if(ic.ne.0)then
	 do ds=1,ic
	 read(2,*)ss
	 enddo
	 endif
          DS=0
	DO WHILE(rstat == 0)
	DS=DS+1
	READ(2,*,IOSTAT=rstat) x1
	IF(rstat /= 0) CLOSE(2)
	enddo
	ds=ds-1
	close (unit=2)
	return
	end subroutine  DataS  !(IN)
	end module   DataSeize

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	PROGRAM main
	use FixPrecision
	use DataSeize
	implicit none
	CHARACTER(100)  :: s
	INTEGER(i8)	    :: I,ND,NPD
	real(R15)       :: xj,xs,xno
	REAL(R15),ALLOCATABLE  :: X(:),Y(:)
	call DataS(IN)
	ALLOCATE(X(0:DS),Y(0:DS))
	ND=DS
	OPEN(UNIT=2,FILE=in,STATUS='UNKNOWN')
	 OPEN(UNIT=3,FILE='ortho',STATUS='UNKNOWN')
	 OPEN(UNIT=4,FILE='mono',STATUS='UNKNOWN')
	if(ic.ne.0)then
   	write(*,*)'# The following',ic,'lines ignored'
 !  	write(3,*)'# The following',ic,'lines ignored'
	do i=1,Ic
	read(2,'(A70)')s
	write(*,'(A70,a)')s,'#Ignored'
!	write(3,'(A70,a)')s,'#Ignored'
    	ENDDO
    	write(3,*)'# --------------------------------------------'
!    	write(3,*)'# --------------------------------------------'
    	endif
    	xno=0.
	do i=1,ND
	read(2,*)x(i),y(i),xj,xj,xj,xs
	xno=xs*xs+xno
	enddo
	xno=sqrt(xno)
	close(2)
    	WRITE(*,'(''     Ply order to fit :- '')')
    	WRITE(*,'(''     Give -1 to select the lowest mono-poly order   '')')
    	WRITE(*,'(''     or  '')')
    	WRITE(*,'(''     Give a poly order to fit '')')
	read(*,*)npd
	write(4,*)' # RMS Noise in signal',xno
	write(3,*)' # RMS Noise in signal',xno
	write(*,*)' # RMS Noise in signal',xno


        CALL ortho_OP(x,y,nD,npD)
      	 STOP ;  END

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	SUBROUTINE PARABOLIC_INTRA(X,y,R0,C0)   ! corrected 12/6/23
    	use FixPrecision
    	IMPLICIT NONE
    	REAL(R15)  :: C0
    	REAL(R15)  :: A, B,C,de
    	REAL(R15)  :: X(0:3),y(0:3)
       REAL(R15)  :: r0

     	de = (x(1)-x(2)) * (x(1)-x(3)) * (x(2)-x(3));
     	A  = (x(3) * (y(2)-y(1)) + x(2) * (y(1)-y(3)) + x(1) * (y(3)-y(2))) / de
     	B  = (x(3)*x(3) * (y(1)-y(2)) + x(2)*x(2) * (y(3)-y(1)) + x(1)*x(1) * (y(2)-y(3))) / de
     	C  = (x(2) * x(3) * (x(2)-x(3)) * y(1)+x(3) * x(1) * (x(3)-x(1)) * y(2)+x(1) * x(2) * (x(1)-x(2)) * y(3)) / de
    	c0=a*r0*r0+b*r0+c  ! working
	! de = (x1 - x2) * (x1 - x3) * (x2 - x3)
	! A     = (x3 * (y2 - y1) + x2 * (y1 - y3) + x1 * (y3 - y2)) / de
	!B     = (x3**2 * (y1 - y2) + x2**2 * (y3 - y1) + x1**2 * (y2 - y3)) / de
	!C     = (x2 * x3 * (x2 - x3) * y1 + x3 * x1 * (x3 - x1) * y2 + &
	!            x1 * x2 * (x1 - x2) * y3) / de
	!xm = -B / (2.*A)  ! x min
	!ym  = C - B**2 / (4.*A)  ! y min
	!write(*,*)x(1),x(2),x(3),xm
	!write(*,*)y(1),y(2),y(3),ym
    	return
	end
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	SUBROUTINE che_grid(sp,xt,yt,xn,yn)
    	use FixPrecision !
    	use DataSeize
  !  	 Use, intrinsic :: iso_fortran_env
    	IMPLICIT none
    	INTEGER(i8)        :: k,sp,l
    	REAL(R15)       :: yT(0:sp+1),xT(0:sp+1)
    	REAL(R15)       :: x1(0:3),y1(0:3),x_e,yr
	REAL(QP)        :: xn(0:sp+1),yn(0:sp+1)
	k=1
	do l =1,sp
 	99 continue
	if(xt(k).lt.xn(l))then
	k=k+1
	if(xt(k).eq.xt(sp))then
	k=k-1
	else
	goto 99
	endif
	endif
	x1(1)=xt(k-1)
   	y1(1)=yt(k-1)
   	x1(2)=xt(k)
   	y1(2)=yt(k)
   	x1(3)=xt(k+1)
   	y1(3)=yt(k+1)
   	x_e=xn(l)
 	CALL PARABOLIC_INTRA(X1,y1,x_e,Yr)
 	yn(l)=yr
 	!if(l.lt.100.or.l.gt.sp-100)then
   	!write(*,*)l,x1(1)
   	!write(*,*)l,x1(2),xn(l),yn(l)
   	!write(*,*)l,x1(3)
   	!write(*,*)'----------------'
   	!endif
	k=k-1
	enddo
!	do ii=1,sp
!	if(ii.lt.100.or.ii.gt.sp-100)then
!   	write(*,*)'i,xn,yn',ii,xn(ii),yn(ii)
!   	write(*,*)'----------------'
!   	endif
!   	enddo
 	return ; END

	SUBROUtine  ortho_OP(x,y,np,dp)
	 ! working :12/09/2023
   	use FixPrecision
   	use DataSeize
   	! Use, intrinsic :: iso_fortran_env
   	IMPLICIT none
   	!CHARACTER(10) :: error
        INTEGER(i8), INTENT(IN)      :: np
    	INTEGER (i8)      :: I,J,kk,KL,ii,jj,DP,dps,dpe,SP
    	REAL(R15), INTENT(IN)    :: X(0:np+1),Y(0:np+1)
        REAL(R15)    :: eor1,em,emr
    	REAL(R15), allocatable    :: eom(:),DER(:),an(:),emm(:)
        REAL(QP), allocatable    :: BN(:),BR(:),a(:),C(:,:),x1(:),x2(:),t(:,:),yc(:),xn(:),yn(:),xt(:)
        REAL(QP)    :: spf,t1,t2,t3,tq,pi,al,be
    	allocate(XN(0:np+1),YN(0:np+1),yc(0:np+1),xt(0:np+1))

        if(dp.gt.np-1)dps=np-1
    	if(dp==-1)then
    	DPS=NP-2
	else
	dps=DP
	endif
	sp=np
    	allocate(Eom(0:dps+3),emm(0:dps+3),DER(1:Dps+3),an(0:dps+3))
    	allocate(x1(0:dps+3),x2(0:dps+3),a(0:dps+3))
        allocate (t(-1:dps+3,0:sp+1))
	pi=2.q0*ASin(1.q0)
	tq=pi/dfloat(sp)
	t2=x(sp)+x(1)
	t1=x(sp)-x(1)
	do i=1,sp
	t3=-Cos((i-.5q0)*1.q0*tq)   !roots
	xn(i)=(t2+t1*t3)*.5q0  !corresponding x
	if(i.lt.20.or.i.gt.sp-20)then
   	endif
	enddo
	call che_grid(sp,x,y,xn,yn)
	al=2.q0/t1  ; be=-t2/t1  !
	!do i=1,20 ; write(*,*)i,xn(i),al*xn(i)-be,yn(i) ; enddo
	!do i=sp-20,sp ; write(*,*)i,xn(i),al*xn(i)-be,yn(i)  ; enddo
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	do ii=1,sp ; xn(ii)=(al*xn(ii)+be) ; enddo  !@@@@@@@@@@@@@@@@

	!do i=1,20 ; write(*,*)i,xn(i)/2.q0,yn(i) ; enddo
	!do i=sp-20,sp ; write(*,*)i,xn(i)/2.q0,yn(i)  ; enddo
	eor1=1.e20
	YC=0.
	t1=0.
	kk=1
	X1=0.q0
	X2=0.q0
	i=0
	spf=1.q0/float(sp)
	OPEN(UNIT=5,FILE='error',STATUS='UNKNOWN')
	do while (kk.eq.1)
	do j=1,sp
	t(0,j)=1.q0
	if(i.eq.0)then
    	x1(i)=x1(i)+yn(j)
   	!x2(i)=x2(i)+1.q0
   	!write(*,*)yn(j),t(i,j),x1(i),x2(i)
   	goto 88
    	endif
    	if(i.eq.1)then
       	t(I,J)=xn(j)
    	x1(i)=x1(i)+t(I,j)*yn(j)
   	goto 88
 	endif
	t(i,j)=2.q0*(xn(j))*t(i-1,j)-t(i-2,j)     !ori
	x1(i)=x1(i)+t(i,j)*yn(j)
88 	continue
	enddo
!	A(I)=X1(I)/x2(I)
	a(i)=x1(I)*spf*2.q0
	if(I.eq.0)a(0)=a(0)*.5q0	!  @@@@@@@@
!	write(*,*)i, x1(i),x2(i),A(i)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! termination to avoid overflow
!	if(x2(i).gt.1.q4900)then!
!	kk=0
!	write(*,*)' # Terminated to avoid overflow at',i
!	write(3,*)'# Terminated to avoid overflow at',i0
!	endif
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	Eom(I)=0.
	do ii=1,sp
	yc(ii)=yc(ii)+a(I)*t(I,ii)
       	eom(i)=eom(i)+(yc(ii)-yn(ii))*(yc(ii)-yn(ii)) !
    	enddo
    	!if(dp.ne.-1)write(*,*)'Ortho poly fit error ',i,eom(i)
    !	write(*,*)'Ortho poly fit error ',i,sqrt(eom(i))
    	!write(5,*)i,sqrt(eom(i))
	if(eom(i).Lt.eor1)then
	eor1=eom(i)
	ELSE
	if(dp.eq.-1)then
	kk=0
	do ii=1,sp
	yc(ii)=yc(ii)-a(I)*t(I,ii)
    	enddo
    	endif
	dpe=i-1
	endif
	write(5,*)i+1,sqrt(eom(i))
	i=i+1
	if(i.gt.dps)kk=0
	enddo  ! SCAN OVER DEGREE
	dpe=i-1
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	write(3,*)'#####################################################'
	write(*,*)'#####################################################'
	write(*,*)'See the file:-ortho mono & error '
	write(*,*)'# Ortho Poly order used and RMS error',DPE,sqrt(eom(dpe))
!	write(3,*)t2
	write(3,*)'# Ortho Poly order used and RMS error',DPE,sqrt(eom(dpe))
	!write(3,*)'  '
 	 t1=(x(sp)-x(1))/2.q0
	 t2=(x(sp)+x(1))/2.q0
	do i=1,sp ; write(3,'(f20.10,5(2X,F20.10))')t1*xn(i)+t2,yn(i),yc(i),YC(I)-YN(I) ; enddo
	close (unit=5)
 	deallocate(t,x1,x2)
	If(dpe.gt.120)dpe=120
    	allocate(C(-3:Dpe+1,-3:Dpe+1),bn(0:dpe+1),BR(0:DPe+1))
	goto 99999  ! this is for [-1,1] range
! 	calculating MONO coefficients
 	C=0.
	c(0,0) =1.q0
        c(1,1)=1q0
   	c(1,0)=0.
        DO I=2,DPE
      	do j=0,dpe
	c(i,j)=(2.q0*c(i-1,j-1)-c(i-2,j))
        enddo
        enddo
99999 continue
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!	goto 8888
! 	calculating MONO coefficients
	C=0.
 	c(0,0) = 1.q0
        c(1,1)=al
   	c(1,0)=be
        DO I=2,DPE
      	do j=0,dpe
	c(i,j)=(2.q0*al*c(i-1,j-1)+2.q0*be*c(i-1,j)-c(i-2,j))  !
        enddo
        enddo
	 t1=(x(sp)-x(1))/2.q0
	 t2=(x(sp)+x(1))/2.q0
	do i=1,sp ; xn(i)=t1*xn(i)+t2 ; enddo

	!   do i=1,20 ; write(*,*)i,xn(i),yn(i) ; enddo
	!do i=sp-20,sp ; write(*,*)i,xn(i),yn(i)  ; enddo

!8888 continue
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

!	DO I=0,DPE ;  WRITE(*,'((1010(i3,D15.5)))')(j,C(I,J), J=0,I) ; ENDDO
!	write(*,*)' '
!	DO I=0,DPE ;  WRITE(3,'((1010(2X,D15.5)))')(j,C(I,J), J=0,I) ; ENDDO

!@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	emr=1.d30
	do kl=0, dpe
	DO J=0,kl
	BN(j)=0.q0
	DO I=J,kl
	BN(J)=BN(J)+C(I,J)*a(i) ! a(i+1)
	ENDDO
	ENDDO
!	WRITE(*,*)'B-----------'
!  	WRITE(*,'(10(10(i3,E15.5)))')(i,BN(I),I=0,KL)
!!!!!!!!!!!!!!!!!!!!!!!!
 		em=0.
 		do i=1,sp
      		 t1 = bn(kl)*(Xn(i)) !!!!!!!!!!!!!!!!!!!!!!!!!
  		do j=kl-1,1,-1
  	  	t1 = (bn(j)+t1)*(Xn(i))  !!!!!!!!!!!!!!!!!!!!!!!!
  		end do
  		t1 = t1+bn(0)
		yc(i)=t1      		!HORNER algoritham for polynomials.
	   	em=em+(yc(i)-yn(i))*(yc(i)-yn(i))
 	   	enddo
		br=bn
		jj=kl
 !		if(dp.eq.-1) then
	    if(em.lt.emr)then
	    br=0.
	    br=bn
	    emr=em
	    jj=kl
	    else
!	    jj=kl-1  !!!!!!!!!!!!!!!!!!!!!
	     exit
	    endif
!	    write(*,*)'poly order & error ',jj,emr
!	    endif
	    enddo
	   	do i=1,np
      		 t1 = br(kl)*(X(i)) !!!!!!!!!!!!!!!!!!!!!!!!!
  		do j=kl-1, 1, -1
  	  	t1 = (br(j)+t1)*(X(i))  !!!!!!!!!!!!!!!!!!!!!!!!
  		end do
  		t1 = t1+br(0)
		yc(i)=t1      		!HORNER algoritham for polynomials.
 	   	enddo
! 	   	write(*,*)'poly order & error ',kl,em
    	WRITE(*,*)'######################################################## '
	write(*,*)'See the file:-mono'
	write(*,*)'#  Poly order & RMS error',KL-1,sqrt(emr)
	WRITE(*,*)'######################################################## '
  	write(*,*)'# Degree & Poly Coefficients '
	kk=(kl-1)/5  !
	do i=0, kk-1
	jj=i*5
	WRITE(*,'(5(i3,2X,e30.20,5x))')(j+jj,Br(j+jj),j=0,4)
	enddo
	if((kk-1)*5.ne.(kl-1))WRITE(*,'(5(i3,2X,e30.20,5x))')(j,Br(j),j=(kk*5),kl-1)
	WRITE(*,*)'------------------'
	write(4,*)'#  Poly order & RMS error',KL-1,sqrt(emr)
    	do i=1,np ; write(4,'(5(2X,F20.5))')X(I), y(i),yc(i),Y(I)-YC(I) ; enddo
    	write(4,*)' '
    	write(4,*)'# Degree & Poly Coefficients '
    	WRITE(4,*)'****************************************************** '
    	do i=0, kk-1
	jj=i*5
	WRITE(4,'(5(i3,2X,e30.20,5x))')(j+jj,Br(j+jj),j=0,4)
	enddo
	if((kk-1)*5.ne.(kl-1))WRITE(4,'(5(i3,2X,e30.20,5x))')(j,Br(j),j=(kk*5),kl-1)
    	WRITE(4,*)'****************************************************** '

! 	Binomial coefficients
!	S=0.
!	s(0,0)=1.
!	s(1,0)=1.
!	s(1,1)=1.
!	do i=1,dpe
!	do j=1,I-1
!	s(i,j)= (s(i-1,j-1)+s(i-1,j))
!	enddo
!	s(i,i)=1.
!	s(i,0)=1.
!	enddo
!	do i=0,dpe
!	do j=0,i
!	s(i,j)= s(i,j)*(-bb)**(j)
!	VALID FOR DPE<123
!	enddo
!	enddo
!	s(0,0)=1.q0
!	WRITE(*,*)'S---------------'
!	DO I=0,DPE ; DO J=0,I ; WRITE(*,*)I,J,(s(I,J)) ; ENDDO ; ENDDO
! 	DO I=0,DPE ; DO J=0,I ; WRITE(3,*)I,J,(s(I,J)) ; ENDDO ; ENDDO
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!	   T1=1.q0
! 	   YC(I)=BN(0)
! 	   DO J=1,kl
! 	   T1=T1*(XN(I)-BB)
! 	   YC(I)=YC(I)+BN(J)*T1
! 	   enddo
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

   	stop
    	end

