!22/06/23 DIRECT ( mono WORKING new, int, es)
	Module FixPrecision        ! To Fix_precision
	! Kind values available
	! Integer:p=1,2,4,8
	! Real:p=4,8,15
	! Complex:-1xp;p=4,8,15
	! logical:-1xp,p=1,4
	implicit none
	integer, parameter,public    :: I1=SELECTED_INT_KIND(1)
	integer, parameter,public    :: i2=SELECTED_INT_KIND(2)
	integer, parameter,public    :: i4=SELECTED_INT_KIND(4)
	integer, parameter,public    :: i8=SELECTED_INT_KIND(8)
	integer, parameter,public    :: R4 =SELECTED_REAL_KIND(4)
	integer, parameter ,public   :: R8 =SELECTED_REAL_KIND(8)
	integer, parameter,public    :: R15=SELECTED_REAL_KIND(15)
	integer, parameter,public    :: qp = selected_real_kind(33)
	!integer, parameter          :: qp = selected_real_kind(p=30)
	!integer, parameter          :: qp = selected_real_kind (32)
	! examples
	!integer(i4) :: ND
	!real(R15) :: X
	!real(R15), parameter :: pi
	!pi=2._dp*asin(1._r15)
	end Module FixPrecision
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	module DataSeize    ! find data seize and get data
	use FixPrecision
	implicit none
	INTEGER(i8), public :: DS
	INTEGER(i8), public :: NPS,ic
	contains
	subroutine DataS (IN)
	implicit none
	CHARACTER(10) :: in
	CHARACTER :: ss
	INTEGER :: rstat
	real(R4)    :: x1
	WRITE(*,'(''    Input file Name    = '')')
	READ(*,*)in
    	OPEN(UNIT=2,FILE=in,STATUS='UNKNOWN')
	WRITE(*,'(''     Nos Lines  considered as Comment   :- '',i2)')
	read(*,*)Ic
	rstat = 0
	if(ic.ne.0)then
	 do ds=1,ic
	 read(2,*)ss
	 enddo
	 endif
          DS=0
	DO WHILE(rstat == 0)
	DS=DS+1
	READ(2,*,IOSTAT=rstat) x1
	IF(rstat /= 0) CLOSE(2)
	enddo
	ds=ds-1
	close (unit=2)
	return
	end subroutine  DataS  !(IN)
	end module   DataSeize
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	PROGRAM main
	use FixPrecision
	use DataSeize
	implicit none
	CHARACTER(10)   :: IN
	CHARACTER(100)  :: s
	INTEGER(i8)	    :: I,ND,NPD,nf
	real(R15)       :: xj,xs,xno
	REAL(R15),ALLOCATABLE  :: X(:),Y(:)
	call DataS(IN)
	ND=DS
	OPEN(UNIT=2,FILE=in,STATUS='UNKNOWN')
!	WRITE(*,'(''     out  file Name      = '')')
!	READ(*,*)out
	 OPEN(UNIT=3,FILE='ortho',STATUS='UNKNOWN')
	 OPEN(UNIT=4,FILE='mono',STATUS='UNKNOWN')
	if(ic.ne.0)then
   	write(*,*)'# The following',ic,'lines ignored'
 !  	write(3,*)'# The following',ic,'lines ignored'
	do i=1,Ic
	read(2,'(A70)')s
	write(*,'(A70,a)')s,'#Ignore'
!	write(3,'(A70,a)')s,'#Ignored'
    	ENDDO
    	write(*,*)'# --------------------------------------------'
!    	write(3,*)'# --------------------------------------------'
    	endif
	OPEN(UNIT=8,FILE='error',STATUS='UNKNOWN')
        write(*,*)' '
	write(*,*)'Give Number of fake nodes to be added (0-5 )'	
	read(*,*)nf
	write(8,*)'Number of fake nodes added',nf
	ALLOCATE(X(0:DS+2*nf+1),Y(0:DS+2*nf+1))
	xno=0.
	do i=1,ND
	read(2,*)x(i),y(i),xj,xj,xj,xs
	xno=xs*xs+xno
	enddo
	xno=sqrt(xno)
	close(2)
    	WRITE(*,'(''     Ply order to fit :- '')')
    	WRITE(*,'(''     Give -1 to select the lowest mono-poly order   '')')
    	WRITE(*,'(''     or  '')')
    	WRITE(*,'(''     Give a poly order to fit '')')
    	WRITE(*,*)'Highest possible value is :- ',nd-1
	read(*,*)npd
	write(4,*)' # RMS Noise in signal',xno
	write(3,*)' # RMS Noise in signal',xno
	write(*,*)' # RMS Noise in signal',xno
        CALL ortho_OP(nf,x,y,nD,npD)
      	 STOP ;  END
SUBROUTINE	PARABOLIC_INTRA(X,y,R0,C0)   ! corrected 12/6/23
    	use FixPrecision
    	IMPLICIT NONE
    	REAL(R15)  :: C0
    	REAL(R15)  :: A, B,C,de
    	REAL(R15)  :: X(0:3),y(0:3)
    	REAL(QP)        :: r0

     	de = (x(1)-x(2)) * (x(1)-x(3)) * (x(2)-x(3));
     	A  = (x(3) * (y(2)-y(1)) + x(2) * (y(1)-y(3)) + x(1) * (y(3)-y(2))) / de
     	B  = (x(3)*x(3) * (y(1)-y(2)) + x(2)*x(2) * (y(3)-y(1)) + x(1)*x(1) * (y(2)-y(3))) / de
     	C  = (x(2) * x(3) * (x(2)-x(3)) * y(1)+x(3) * x(1) * (x(3)-x(1)) * y(2)+x(1) * x(2) * (x(1)-x(2)) * y(3)) / de
    	c0=a*r0*r0+b*r0+c  ! working
! 	de = (x1 - x2) * (x1 - x3) * (x2 - x3)
! 	A     = (x3 * (y2 - y1) + x2 * (y1 - y3) + x1 * (y3 - y2)) / de
!	B     = (x3**2 * (y1 - y2) + x2**2 * (y3 - y1) + x1**2 * (y2 - y3)) / de
!	C     = (x2 * x3 * (x2 - x3) * y1 + x3 * x1 * (x3 - x1) * y2 + &
!            x1 * x2 * (x1 - x2) * y3) / de
!	xm = -B / (2.*A)  ! x min
!	ym  = C - B**2 / (4.*A)  ! y min
!	write(*,*)x(1),x(2),x(3),xm
!	write(*,*)y(1),y(2),y(3),ym
    	return
	end

	SUBROUTINE EQ_FI(nf,NP,start,step_es,XT,YT,xn,yn,nsp)
!   	checked 
    	use FixPrecision !
    	use DataSeize
    	IMPLICIT none
    	INTEGER(i2)        :: bv
    	INTEGER(i8)        :: NP,NPN,I,KL,KS,L,L2,k,nsp,kk,nf
    	REAL(R15)       :: yT(0:np+1),xT(0:np+1),sl,sl1,sh,sh1
    	REAL(R15)       :: x1(0:3),y1(0:3),y2(0:12),YR
    	REAL(R15)       :: s_noise
    	REAL(R15)       :: yn1(0:NsP+1) ! define dimension
	REAL(qp)        :: XN(0:NsP+1),YN(0:NsP+1)
	REAL(QP)        :: start,step_es,x_e,c1,c2

	k=1
	if(start.le. xt(1))then
     	start=xt(1)*1.q0
     	xn(nf+1)=xt(1)
     	yn(nf+1)=yt(1)
     	else
   	k=1
110     if(start.gt.xt(k))then
    	K=K+1
    	goto 110
     	ENDIF
     	xn(nf+1)=XT(k)
     	YN(nf+1)=YT(k)
     	endif
!     	write(*,*)'k,start',k,start
 !    	do l=0,6 ; write(*,*)'k,xt(k),yt(k)',k+l,xt(k+l),yt(k+l) ; enddo

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	kk=int((xt(np)-xt(1))/step_es)
	i=1
	kl=1+nf
	xn(1)=start
	yn(1)=yt(1)
	do l =2,(kk)
	kl=kl+1
	xn(kl)=xn(kl-1)+step_es
	i=i+1

1	c1=xn(kl)-xt(i)
	c2=c1/10.d0
	if(c1.gt.(xt(i)-xt(i-1)+c2))then
	i=i+1
	goto 1
	endif
2	c2=xn(kl)-xt(i+1)
	if(abs(c2).le.abs(c1))then
	c1=c2
	i=i+1
	goto 2
	else
	i=i-1
	endif
				x1(1)=xt(i)
   				y1(1)=yt(i)
   				x1(2)=xt(i+1)
   				y1(2)=yt(i+1)
   				x1(3)=xt(I+2)
   				y1(3)=yt(i+2)
   	x_e=xn(kl)
 	CALL PARABOLIC_INTRA(X1,y1,x_e,Yr)
 	yn(kl)=YR
! 	write(*,*)'i,xt,yt,            ',i,xt(i),yt(i)
!   	write(*,*)'i,xt,yt,kl, xn,yn   ',i+1,xt(i+1),yt(i+1),kl,xn(kl),yn(kl)
 !  	write(*,*)'i,xt,yt             ',i+2,xt(i+2),yt(i+2)
!	write(*,*)'______'
	enddo
	kl=kl+1
	xn(kl)=xn(kl-1)+step_es
	yn(kl)=yt(np)
!	write(*,*)'kl,XN,YN                              ',kl,XN(kl),yn(kl)
!       write(*,*)'kl',kl

	if(nf.ne.0)then
 	write(*,*)'Give choice of boundary condition'
  	write(*,*)'Give zero for best fit to op'
 	 write(*,*)'Give 1 for best fit to monomial'
  	read(*,*)bv
	if(bv.ne.0)then
 	write(8,*)'gives correct mono (op converges fast but may diverge at higher polynomial digrees)'
 	else
	write(8,*)'gives non diverging, but slower converging, op'
	endif
	if(bv.eq.2)then
	sl1=yt(1)  !+sl
	sl=sl1/float(nf)
!	write(*,*)'sl',sl
	sh1=yt(np)   !+sh
	sh=sh1/float(nf)
!	write(*,*)'sh@@',sh
	endif
	do i=1,nf
	xn(nf+1-i)=xn(nf+2-i)-step_es
	if(bv.eq.0)yn(nf+1-i)=0.
	if(bv.eq.1)yn(nf+1-i)= yt(1)
		if(bv.eq.2)then
		sl1=sl1-sl
		if(sl1.lt.0.)sl1=0
		!write(*,*)'sl1',yt(1),sl1
		yn(nf+1-i)= sl1
		endif
		kl=kl+1
		xn(kl)=xn(kl-1)+step_es
		if(bv.eq.0)yn(kl)=0.
 		if(bv.eq.1) yn(kl)= yt(np)
 		 if(bv.eq.2)then
		sh1=sh1-sh
		if(sh1.lt.0.)sh1=0
		yn(kl)= sh1
		!write(*,*)'sh1',yt(np),yn(kl)
		endif
!		write(*,*)kl,xn(kl),yn(kl)
		enddo
		endif
		 npn=kl
 		NSP=NPN
! 	do i=1,kl ; write(*,*)i,xn(i),yn(i) ; enddo
	RETURN     !
	END
	SUBROUtine  ortho_OP(nf,x,y,np,dp)
	 ! working :
   	use FixPrecision
   	use DataSeize
   	IMPLICIT none
   	integer(i2) is
        INTEGER(i8), INTENT(IN)      :: np
    	INTEGER (i8)      :: I,J,kk,KL,ii,jj,DP,dps,dpe,SP,sp_s,sp_e,nsp,nf
    	REAL(R15), INTENT(IN)    :: X(0:np+1),Y(0:np+1)
        REAL(R15)    :: eor1,em,emr
    	!REAL(R15), ALLOCATABLE   :: YN(:)
    	REAL(R15), allocatable    :: eom(:),DER(:),an(:),emm(:)
    	REAL(QP)    :: spf,dpf,dpfi,T1,T2,Spi,start,es,alf,be
	REAL(QP), allocatable    :: BN(:),BR(:),a(:),al(:),ga(:),C(:,:),x1(:),x2(:),t(:,:),yc(:),s(:,:),xn(:),xt(:),yn(:)
 	if(dp==-1)then
    	DPS=NP-2
	else
	dps=DP
	endif
    	allocate(Eom(0:dps+3),emm(0:dps+3),DER(1:Dps+3),an(0:dps+3),s(0:dps+3,0:dps+3))
    	allocate(x1(0:dps+3),x2(0:dps+3),a(0:dps+3),al(0:dps+3),ga(0:dps+3))
	write(*,*)' '
!	write(*,*)'Choose the grid to use'
!	write(*,*)'To include [-1,1] give 0'
!	write(*,*)'To exclude [-1,1] with it in the extended grid, give 1'
!	write(*,*)'To exclude [-1,1]; G-poly grid, give 1'
!	write(*,*)'2 gives the best results'
!	read(*,*)is
!	if(is.eq.1)is=2
	IS=2
	OPEN(UNIT=8,FILE='error',STATUS='UNKNOWN')
        sp=np
       	start=(int(x(1)*100.q0))*.01q0
	es=abs(dfloat(int((x(2)-x(1))*1000.q0)))*.001q0
	nsp=int((x(sp)-x(1))/es)+2*nf
 	allocate (xn(0:nsp++1),xt(0:nsp+1),yn(0:nsp+1),yc(0:nsp+1),t(0:dps+3,0:nsp+1))
	call EQ_FI(nf,sp,start,es,X,Y,xn,yn,nsp)
	sp=nsp
	if(dps.gt.sp-1)dps=sp-1
	if(is.eq.0)then
!	t2=xn(sp)+xn(1)   !        including [-1,1]
!	t1=xn(sp)-xn(1)
!	alf=2.q0/t1  ; be=-t2/t1  !@@@@@@@@@@ sign
!    	do i=1,sp
! 	xt(I)=xn(I)*alf+be  ! @@@@@@
! 	write(*,*)xt(i), xt(i)-xt(i-1)  ! including [-1,1]
!    	enddo
! alternate
  	t1=2.q0/dfloat(sp-1)
	do i=0,sp-1
 	xt(I+1)=-1.q0+dfloat(i)*t1   ! sp eqispaced points including [-1,1] correct
    	enddo
   	write(*,*)'[-1,1] included'
    	write(3,*)'[-1,1] included'
     	write(4,*)'[-1,1] included'
	endif
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	if(is.eq.1)then
    	t1=2.q0/dfloat(sp+1)
  	do i=1,sp
  	xt(I)=-1.q0+dfloat(i)*t1   ! sp eqispaced points excluding [-1,1].BUT [-1,1] is contained in the extended grid
    	enddo
    	 write(*,*)'[-1,1] excluded; but present in extended grid'
    	 write(3,*)'[-1,1] excluded; but present in extended grid'
    	 write(4,*)'[-1,1] excluded; but present in extended grid'
    	endif
!!!!!!!!!!!!!!!!!!!!!
	if(is.eq.2)then
! 	best results
	spf=float(sp)*1.q0 !
	spi=1.q0/spf
    	do i=1,sp
 	xt(I)=-1.q0+(dfloat(2*i-1))*spi    ! sp eqispaced points AVOIDING [-1,1]
    	enddo
    	write(*,*)'[-1,1] excluded; G-poly grid '
    	write(3,*)'[-1,1] excluded; G-poly grid '
    	write(4,*)'[-1,1] excluded; G-poly grid'
	endif
	 if(is.eq.0)write(8,*)'[-1,1] included'
	 if(is.eq.1)write(8,*)'[-1,1] excluded; but present in extended grid'
 	 if(is.eq.2)write(8,*)'[-1,1] excluded; not present in extended grid'
	A=0.q0
	eor1=1.e20
	YC=0.
	kk=1
	sp_s=1      !
	sp_e=sp
	i=0
	do while (kk.eq.1)
	X1(I)=0.q0
	X2(i)=0.q0
 	i=i+1
 	dpf=dfloat(i)*1.q0
 	dpfi=1.q0/dpf
 	al(i-1)=((4.q0-dpfi*dpfi)/(1.q0-dpf*dpf*spi*spi))**.5q0
 	!write(*,*)i-1,al(i-1)
 	i=i-1
	do j=sp_s,sp_e
	if(i.eq.0)then
       	t(0,j)=1.q0
    	x1(i)=x1(i)+t(i,j)*yn(j)
	x2(i)=x2(i)+t(i,j)*t(i,j)
	goto 9999
    	endif
    	if(i.eq.1)then
       	t(I,J)=xt(j)*Al(0)
    	x1(i)=x1(i)+t(i,j)*yn(j)
	x2(i)=x2(i)+t(i,j)*t(i,j)
	goto 9999
 	endif
	t(i,j)=(xt(j)*t(i-1,j)-t(i-2,j)/al(i-2))*al(i-1)
	x1(i)=x1(i)+t(i,j)*yn(j)
	x2(i)=x2(i)+t(i,j)*t(i,j)
 9999 continue
	enddo
	A(I)=X1(I)/x2(I)
	!if(x2(i).gt..9q4900)then
	!kk=0    ! check overflow
	!write(*,*)'terminated to avoid overflow at',i
	!write(3,*)'terminated to avoid overflow at',i
	!endif
	Eom(I)=0.
	do ii=1,sp
	yc(ii)=yc(ii)+a(I)*t(I,ii)
       	eom(i)=eom(i)+(yc(ii)-yn(ii))*(yc(ii)-yn(ii)) !
    	enddo
	write(8,*)i,eom(i)
	if(eom(i).Lt.eor1)then
	eor1=eom(i)
	ELSE
	if(dp.eq.-1)then
	do ii=1,sp
	yc(ii)=yc(ii)-a(I)*t(I,ii)
    	enddo
	kk=0
	endif
	endif
	i=i+1
	if(i.gt.dps+1)kk=0  !!!!!!!!!!!!!!!!!!!
	enddo  ! SCAN OVER DEGREE
	dpe=i-1	  !!!!!!!!!!!!!!!!!!!!!!!!!!
	write(3,*)'#####################################################'
	write(*,*)'See the file:-ortho mono & error'
	write(*,*)'# Ortho Poly order used and RMS error',DPE,sqrt(eom(dpe-1))
	write(3,*)'# Ortho Poly order used and RMS error',DPE,sqrt(eom(dpe-1))
	write(3,*)'  '
	if(is.eq.0)then ! for [-1,1] included case
	t1=(xn(sp)-xn(1))/2.q0
	t2=(xn(sp)+xn(1))/2.q0
	endif
	if(is.eq.1)then ! for [-1,1] Avoided case
	 t1=(es+es+xn(sp)-xn(1))/2.q0
	 t2=(xn(sp)+xn(1))/2.q0  !@@@@@@@@@@@@
	endif

	if(is.eq.2)then ! for [-1,1] Avoided case
	 t1=(es+xn(sp)-xn(1))/2.q0
	 t2=(xn(sp)+xn(1))/2.q0  !@@@@@@@@@@@@
	endif
        do i=1,sp ; write(3,'(5(2X,F15.2))')t1*xt(i)+t2,yn(i),yc(i),YC(I)-YN(I) ; enddo
        deallocate(x1,x2,t)
	allocate(C(-3:Dpe+3,-3:Dpe+3),bn(0:dps+3),BR(0:DPS+3))
!@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	goto 8989  !to skipp [-1,1]
! 	calculating MONO coefficients
	C=0.q0
 	c(0,0)=1.q0
        c(1,1)=al(0)
        DO I=2,DPE
      	do j=0,dpe
	c(i,j)=(c(i-1,j-1)-c(i-2,j)/aL(i-2) )*al(i-1)
        enddo
        enddo
        8989 continue
 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 !   	goto 8888 ! to skipp [x(1),x(sp]
! 	calculating MONO coefficients
	if(is.eq.0)then
	t2=xn(sp)+xn(1)
	t1=xn(sp)-xn(1)
	endif
	if(is.eq.1)then
	t2=xn(sp)+xn(1)
	t1=es+es+xn(sp)-xn(1)
	endif
	if(is.eq.2)then
	t2=xn(sp)+xn(1)
	t1=es+xn(sp)-xn(1) !!!!!!!!!!!!!@@@@@@@@@@@@@@@@@@@@
	endif
	alf=2.q0/t1  ; be=-t2/t1  !@@@@@@@@@@ sign
	C=0.
 	c(0,0) = 1.q0
        c(1,1)=alf*al(0)
   	c(1,0)=be*al(0)
        DO I=2,DPE
      	do j=0,dpe
	c(i,j)=alf*al(i-1)*c(i-1,j-1)+al(i-1)*be*c(i-1,j)-al(i-1)*c(i-2,j)/aL(i-2)
        enddo
        enddo
	  if(is.eq.0)then
	 t1=(xn(sp)-xn(1))/2.q0
	 t2=(xn(sp)+xn(1))/2.q0
	 endif
         if(is.eq.1)then
	 t1=(es+es+xn(sp)-xn(1))/2.q0
	 t2=(xn(sp)+xn(1))/2.q0
	 endif
        if(is.eq.2)then
	 t1=(es+xn(sp)-xn(1))/2.q0
	 t2=(xn(sp)+xn(1))/2.q0
	 endif
	 do i=1,sp ; xt(i)=t1*xt(i)+t2 ; enddo
	!   do i=1,20 ; write(*,*)i,xn(i),yn(i) ; enddo
	!do i=sp-20,sp ; write(*,*)i,xn(i),yn(i)  ; enddo
8888 	continue
!@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!	DO I=0,DPE ;  WRITE(*,'((1010(i3,D15.5)))')(j,C(I,J), J=0,I) ; ENDDO
!	write(*,*)' '
!	DO I=0,DPE ;  WRITE(3,'((1010(2X,D15.5)))')(j,C(I,J), J=0,I) ; ENDDO
!@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
     	dpe=dpe-1  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	emr=1.d30
	do kl=0, dpe
	DO J=0,kl
	BN(j)=0.q0
	DO I=J,kl
	BN(J)=BN(J)+C(I,J)*a(i)
	ENDDO
	ENDDO
!	WRITE(*,*)'B-----------'
 ! 	WRITE(*,'(10(10(i3,E15.5)))')(i,BN(I),I=0,KL)
!!!!!!!!!!!!!!!!!!!!!!!!
 		em=0.
 		do i=1,sp
      		 t1 = bn(kl)*xt(i)  !!!!!!!!!!!!!!!!!!!!!!!!!
  		do j=kl-1, 1, -1
  	  	t1 = (bn(j)+t1)*xt(i)   !!!!!!!!!!!!!!!!!!!!!!!!
  		end do
  		t1 = t1+bn(0)
		yc(i)=t1      		!HORNER algoritham for polynomials.
	   	em=em+(yc(i)-yn(i))*(yc(i)-yn(i))
 	   	enddo
!	    	write(*,*)'poly order & error ',jj,em

		br=bn
		jj=kl
	    if(em.lt.emr)then
	    br=0.
	    br=bn
	    emr=em
	    jj=kl
	    else
	     exit
	    endif
	    enddo
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		do i=1,np
      		 t1 = br(jj)*x(i)   !!!!!!!!!!!!!!!!!!!!!
  		do j=jj-1, 1, -1
  	  	t1 = (br(j)+t1)*x(i)   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  		enddo
  		t1 = t1+br(0)
		yc(i)=t1
 	   	enddo
    	WRITE(*,*)'******************************************************* '
	write(*,*)'------------------'
	write(*,*)'See the file:-mono'
	write(*,*)'#  Poly order & RMS error',KL,sqrt(em)
  	write(*,*)'# Degree & Poly Coefficients '
	kk=(kl-1)/5  !*5
	do i=0, kk-1
	jj=i*5
	WRITE(*,'(5(i3,2X,e30.20,5x))')(j+jj,Br(j+jj),j=0,4)
	enddo
	if((kk-1)*5.ne.(kl-1))WRITE(*,'(5(i3,2X,e30.20,5x))')(j,Br(j),j=(kk*5),kl-1)
	WRITE(*,*)'------------------'
	write(4,*)'#  Poly order & RMS error',KL,sqrt(em)
    	do i=1,np ; write(4,'(i6,5(2X,F20.5))')i,X(I), y(i),yc(i),Y(I)-YC(I) ; enddo
    	write(4,*)' '
    	write(4,*)'# Degree & Poly Coefficients '
    	WRITE(4,*)'****************************************************** '
    	do i=0, kk-1
	jj=i*5
	WRITE(4,'(5(i3,2X,e30.20,5x))')(j+jj,Br(j+jj),j=0,4)
	enddo
	if((kk-1)*5.ne.(kl-1))WRITE(4,'(5(i3,2X,e30.20,5x))')(j,Br(j),j=(kk*5),kl-1)
    	WRITE(4,*)'****************************************************** '
! Binomial coefficients
!	S=0.
!	s(0,0)=1.
!	s(1,0)=1.
!	s(1,1)=1.
!	do i=1,dpe
!	do j=1,I-1
!	s(i,j)= (s(i-1,j-1)+s(i-1,j))
!	enddo
!	s(i,i)=1.
!	s(i,0)=1.
!	enddo
!	do i=0,dpe
!	do j=0,i
!	s(i,j)= s(i,j)*(-bb)**(j)
!	VALID FOR DPE<123
!	enddo
!	enddo
!	s(0,0)=1.q0
!	WRITE(*,*)'S---------------'
!	DO I=0,DPE ; DO J=0,I ; WRITE(*,*)I,J,(s(I,J)) ; ENDDO ; ENDDO
! 	DO I=0,DPE ; DO J=0,I ; WRITE(3,*)I,J,(s(I,J)) ; ENDDO ; ENDDO
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!	   T1=1.q0
! 	   YC(I)=BN(0)
! 	   DO J=1,kl
! 	   T1=T1*(XN(I)-BB)
! 	   YC(I)=YC(I)+BN(J)*T1
! 	   enddo
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   	stop
    	end

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
