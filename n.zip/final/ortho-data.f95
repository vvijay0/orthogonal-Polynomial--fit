
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	PROGRAM planck
    ! The Planck's profile is Calculated and plotted (using Gnuplot)
    	IMPLICIT none
    	INTEGER I,NP
    	character COMMAND*70
    	integer, parameter :: dp = selected_real_kind(15)
    	real(kind=dp)  B1(6),br(6)
    	real(kind=dp)TIME,TIMEB,START,STEP,GRA,S1,GRA1,GRA2,C1,c_m,bu,bl,C2,C22,c3,XT,shift1,sca,sca1,W_SCA,r_n
    	REAL(kind=dp), ALLOCATABLE :: xl(:), C(:),cb(:),co(:)
    	REAL(kind=dp), ALLOCATABLE :: BK(:),BT(:),C11(:),ran1(:)

    	WRITe(*,'(''  Give number of channels required '')')
    	read(*,*)np
    	WRITe(*,'(''  Give step seize required '')')
    	read(*,*)step
     	WRITe(*,'(a,f15.8)') 'Spectral region is',float(np)*step
! Change NP (up to 9999) and step, to Change the spectral range (np*step))

    	allocate(xl(np+1), C(np+1),cb(np+1),co(np+1),BK(np+1),BT(np+1),C11(np+1),ran1(np+1))

    !      		WRITe(*,'(''+OUTPUT FILE NAME'')')
    !      		READ(5,'(A)')FNAME
    !      		WRITe(*,'(''+  BACKGROUND FILE NAME =   '')')
    !      		READ(5,'(A)')BACKG

    	OPEN(4,FILE="T", action="write")
    	OPEN(2,FILE="B",  action="write")
    	WRITe(*,*)'+  GIVE  TEMPERATURE    '
    	READ(*,*)B1(1)
    	WRITe(*,'(''  Emissivity E= E0 + a x Lamda + b x Lamda**2 + c x Lamda**3 '')')
    	WRITe(*,'('' '')')
    	write(*,*)'  For T <300 b & c are set to zero'
    	WRITe(*,'('' '')')
    	WRITe(*,'(''+  GIVE coeficients of emmisivity polynomial with Wavelengh in mico meter'')')
    	WRITe(*,'(''+ ---------------------------(E0, a,b & c)------------------------------'')')
   	 WRITe(*,'(''  '')')
   	 WRITe(*,'('' '')')

    	b1(4)=0.
    	b1(5)=0.
    	if(b1(1).ge.300.)then
        READ(*,*)b1(2),b1(3),b1(4),b1(5)
    	else
        read(*,*)b1(2),b1(3)
    	endif

    	br=b1
    	TIME=1.D0
    	TIMEB=2.D0
    	GRA=0.0001D0
    	S1=1.D0
    	GRA1=.002D0
    	GRA2=.00000001D0
    	start=2.897768*1.d6/b1(1)
    	write(*,'(/)')
    	write(*,'(a,f8.2,a)')' Spectra Peaks near ',start,' nm'
    	write(*,'(/)')
    	start=float(int(start))-float(np)*step/2.
    	if(start<50.)start=200.
    	write(*,'(a,f8.2,a,f4.2,a)')' Spectra have to start at ',start,' with ',step,'(nm) as step  to include the peak'
    	write(*,'(/)')
    	w_sca=0.
   	 WRITe(*,'(a,f10.2)')' To get peak at the centre of the spectral region give ',w_sca
    	write(*,'(a,f10.2)')' To get the pre-peak region of the spectra, give       ',start-(float(np)*step/2.)
    	write(*,'(a,f10.2)')' To get the post-peak region of the spectra, give      ',start+float(np)*step/2.
    	write(*,'(a)')' To get some other region, give its starting value in nm '

    	read(*,*)shift1
    	if(shift1.ne.0.)start=shift1
    	if(start.lt.50.)start=200.
    	write(*,'(a,f8.2,a,f4.2,a)')' Spectra will start from ',start, ' with a step of ',step,'nm '

    	w_sca=1.d-3
    	bu=1.d-20
    	bl=1.d20
    	XL(1)=START
    	XT=XL(1)*w_SCA
    	BT(1)=B1(2)+B1(3)*XT+B1(4)*XT*XT +b1(5)*xt*xt*xt
    	BK(1)=(S1+GRA1*xt)*timeb
    	if(bt(1).gt.bu)bu=bt(1)
    	if(bt(1).lt.bl)bl=bt(1)

    	do i=2,np
        XL(I)=XL(I-1)+STEP+gra
        XT=XL(i)*W_SCA
        BT(I)=B1(2)+B1(3)*XT+B1(4)*XT*XT+b1(5)*xt*xt*xt
        if(bt(i).gt.bu)bu=bt(i)
        if(bt(i).lt.bl)bl=bt(i)
        BK(I)=bk(i-1)+(GRA1*xt)*timeb   !
    	enddo
    	write(*,'(a,x,f7.5,a,x,f7.5)')'The Lowest & highest values of emmisivity are:',bl,' &,',bu
    	if(bu.gt.1.)then
        write(*,'(a,f5.3)')'*******************Emissivity exceeding 1.0 ***********************',bu
        !     write(*,'(a,f5.3,a)')'Reduce E0 up to',-(bu-.99), 'and/or reduce a,b & c and rerun'
        !    write(*,*)'*******************************************************************'
    	endif

    	if(bL.lt..0)then
        write(*,'(a,f5.3)')'Emissivity becoming -ve '
        write(*,'(a,f10.5,a)')'Change E0 to a value > ', b1(2)-bl+.001,' and/or increase starting wavelength and rerun'
        write(*,*)'**********************************************************************'
        stop
    	endif
    	C1=1.d28 ! Insteed of  -> 0.59544D-12*1.D36
    	!C2=1.438776959983816*1.d7 ! When  wave lenghth is in nm (old )
    	!https://www.physics.nist.gov/cgi-bin/cuu/Value?c22ndrc
  	!  c2=14387768770.   ! MICRO m k   !16/08/20
    	c2=14387768.770   ! nm k   !16/08/20
   	 c_m=1.d20
    	do i=1,np
        C11(i)= C1/(XL(I)**5.D0)
        C22=c2/(XL(I)*B1(1))
        C22= EXP(C22)-1.D0
        Cb(i)=C11(i)/C22
        C(I)=BT(I)*cb(i)
        if(c(i).lt.c_m)c_m=c(i)
    enddo
    	time=1.
        sca=1.d0
        if(c_m.ne.100.d0)sca=100.d0/c_m
        c=c*sca
        cb=cb*sca
!goto 9898
	c_m=0.0 ; sca=1.0
	do i=1,np ; if(c(i).gt.c_m)c_m=c(i) ; enddo
	if(c_m>100000.d0)sca=100000.d0/c_m
	if(c_m<6000.d0)sca=6000.d0/c_m
	c=c*sca
    	cb=cb*sca

	if(c(1).lt.10.)then
	write(*,*)'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++'
	write(*,*)'Some counts are lower than 100; consider changing the start value of the spectra'
	write(*,*)'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++'
 	endif
 9898   continue
    	sca=0.
    	write(*,*) '  '
    	WRITE(*,'(''+  Give noise level to be added (try 0-100)     '')')
    	read(*,*)sca
    	if(sca.lt..0)sca=0.
    	if(sca.ne.0.)then
        call  ran_n (ran1,np)
    	c_m=0 ; do i=1, np ; if(ran1(i).lt.c_m)c_m=ran1(i) ; enddo

        ran1=ran1/abs(c_m)
	r_n=0.
        do i=1,np
        co(i)=(c(i)+bk(i)/timeb)*time
         c3=sqrt(c(i))
        ! c(i)=co(i)+(ran1(i))*c3*sca/1.d2
           c(i)=co(i)+(ran1(i))*sca
         r_n=r_n+(c(i)-co(i))*(c(i)-co(i))
         enddo
    	else
        do i=1,np ; co(i)=(c(i)+bk(i)/timeb)*time ; C(I)=co(i) ; enddo
   	 endif
    	WRITE(4,'(a,f15.8,f8.2,4(2x,f17.10))')'# ', time,B1(1),Br(2),Br(3),Br(4),br(5)
    	WRITE(4,'(a,f20.10,2x,f8.2)')'# ', time,B1(1)
  	DO I=1,NP
       ! WRITE(4,'(f8.2, 2x,f15.2,4x,f10.5,3(2x,f15.2))')xl(i),C(i),BT(I),co(i),cb(i)*time,c(i)-co(i)
         WRITE(4,'(f8.2, 2x,f15.2,4x,f10.5,3(2x,f15.2))')xl(i),C(i),c(i)-co(i) !,BT(I),co(i),cb(i)*time
        
    	ENDDO
    	
    	WRITE(4,*)'  '
    	WRITE(4,*)' '
    	WRITE(4,*)'--- '
    	WRITE(4,*)'-- '
    	WRITE(2,*)'# ',TIMEB
    	WRITE(2,*)'# ',TIMEB
    	DO I=1,NP
        WRITE(2,'(f8.2, 2x,f20.2)')XL(I),BK(i)
    	enddo
    	WRITE(2,*)'  '
    	WRITE(2,*)' '
    	WRITE(2,*)'-- '
    	WRITE(2,*)'-- '
    	if(sca.ne.0.)then
        write(4,'(a,f15.2)') ' RMS Noise added '	,sqrt(r_n)
        write(*,'(a,f15.2)') ' RMS Noise added '	,sqrt(r_n)
    	else
        write(4,*) ' Noise NOT added ',r_n
        write(*,*) ' Noise NOT added ',r_n
    	endif
    	write(*,*) ' Effective Poly Coe used '
    	write(4,*) ' Effective Poly Coe used '
    	write(*,*)b1(2),b1(3),b1(4),b1(5)
    	write(4,*)b1(2),b1(3),b1(4),b1(5)
   	 write(4,*)'WL, Prof+N,n, E,Pro,BB_Pro'
    	close(unit=4)
    	open(unit=3,file='gp.plt')
    	write(3,*)'set multiplot '
    	write(3,*)'set xlabel "Wave length"'
    	write(3,*)'set ylabel "Counts"'
    	write(3,*)'set xrange[',xl(1)-10.,":",xl(np)+10.,']'

   	 write(3,*) 'set xtic auto'
   	 write(3,*)'set ytic auto'
   	! write(3,*)'plot "T" every 5 using 1:2 w p pt "." ps 0  notitle '
   	write(3,*)'plot "T" using 1:2 w l  notitle '
    	! write(3,*)'plot "T" using 1:2 w p pt "." ps 0  notitle '
    	!write(3,*)'plot "T" using 1:4 with lines'
    	!write(3,*)'plot "T" with points'
    	!write(3,*)'plot "T" with lines'
    	close(unit=3)
    	COMMAND="gnuplot -p gp.plt "
    	CALL EXECUTE_COMMAND_LINE(COMMAND)	  !only for f95
    	! CALL EXECUTE_COMMAND_LINE (“dir > dir.txt”, EXITSTAT=ESTAT,CMDSTAT=CSTAT, CMDMSG=CMSG)
    	STOP
	END
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	subroutine  ran_n (ran1,np)
    	integer, parameter :: dp = selected_real_kind(15)
    	real(kind=dp)  ran2 ,ran1(np)
    !	DOUBLE PRECISION ran2 ,ran1(np)
    	INTEGER idum,j,i
    	j=1
    	do i=1,np
        idum=-j
        call rans(idum,ran2)
        j=j+1
        ran1(i)=ran2*1.1d1
    	enddo
    	return
	end


subroutine rans(idum,ran1)
    INTEGER idum,IM1,IM2,IMM1,IA1,IA2,IQ1,IQ2,IR1,IR2,NTAB,NDIV
    integer, parameter :: dp = selected_real_kind(15)
    real(kind=dp) AM,EPS,RNMX,ran1
    !DOUBLE PRECISION AM,EPS,RNMX,ran1
    PARAMETER (IM1=2147483563,IM2=2147483399,AM=1./IM1,IMM1=IM1-1,IA1=40014,IA2=40692,IQ1=53668,IQ2=5277)
    parameter (IR1=12211,IR2=3791,NTAB=32,NDIV=1+IMM1/NTAB,EPS=1.2e-7,RNMX=1.-EPS)
    INTEGER idum2,j,k,iv(NTAB),iy
    SAVE iv,iy,idum2
    DATA idum2/123456789/, iv/NTAB*0/, iy/0/
    if (idum.le.0) then
        idum=max(-idum,1)
        idum2=idum
        do j=NTAB+8,1,-1
            k=idum/IQ1
            idum=IA1*(idum-k*IQ1)-k*IR1
            if (idum.lt.0) idum=idum+IM1
            if (j.le.NTAB) iv(j)=idum
        enddo
        iy=iv(1)
    endif
    k=idum/IQ1
    idum=IA1*(idum-k*IQ1)-k*IR1
    if (idum.lt.0) idum=idum+IM1
    k=idum2/IQ2
    idum2=IA2*(idum2-k*IQ2)-k*IR2
    if (idum2.lt.0) idum2=idum2+IM2
    j=1+iy/NDIV
    iy=iv(j)-idum2
    iv(j)=idum
    if(iy.lt.1)iy=iy+IMM1
    ran1=min(AM*iy,RNMX)
    ran1=2.d0*(ran1-.5d0)
!write(*,*)ran1
!pause
    return
END
