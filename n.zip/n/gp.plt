 set multiplot 
 set xlabel "Wave length"
 set ylabel "Counts"
 set xrange[   290.00000000000000      :   5310.4999000012276      ]
 set xtic auto
 set ytic auto
 plot "T" using 1:2 w l  notitle 
