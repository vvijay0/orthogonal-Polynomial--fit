
	Module FixPrecision        ! To Fix_precision
	! Kind values available
	! Integer:p=1,2,4,8
	! Real:p=4,8,15
	! Complex:-1xp;p=4,8,15
	! logical:-1xp,p=1,4
	implicit none
	integer, parameter,public    :: I1=SELECTED_INT_KIND(1)
	integer, parameter,public    :: i2=SELECTED_INT_KIND(2)
	integer, parameter,public    :: i4=SELECTED_INT_KIND(4)
	integer, parameter,public    :: i8=SELECTED_INT_KIND(8)

	integer, parameter,public    :: R4 =SELECTED_REAL_KIND(4)
	integer, parameter ,public   :: R8 =SELECTED_REAL_KIND(8)
	integer, parameter,public    :: R15=SELECTED_REAL_KIND(15)
	integer, parameter,public    :: qp = selected_real_kind(33)
	!integer, parameter          :: qp = selected_real_kind(p=30)
	!integer, parameter          :: qp = selected_real_kind (32)
	! examples
	!integer(i4) :: ND
	!real(R15) :: X
	!real(R15), parameter :: pi
	!pi=2._dp*asin(1._r15)
	end Module FixPrecision
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	module DataSeize    ! find data seize and get data
	use FixPrecision
	implicit none
	INTEGER(i8), public :: DS
	INTEGER(i8), public :: NPS,ic
	contains
	subroutine DataS (IN)
	implicit none
	CHARACTER(10) :: in
	CHARACTER :: ss
	INTEGER :: rstat
	real(R4)    :: x1
	WRITE(*,'(''    Input file Name    = '')')
	READ(*,*)in
    	OPEN(UNIT=2,FILE=in,STATUS='UNKNOWN')
	WRITE(*,'(''     Nos Lines  considered as Comment   :- '',i2)')
	read(*,*)Ic
	rstat = 0
	if(ic.ne.0)then
	 do ds=1,ic
	 read(2,*)ss
	 enddo
	 endif
          DS=0
	DO WHILE(rstat == 0)
	DS=DS+1
	READ(2,*,IOSTAT=rstat) x1
	IF(rstat /= 0) CLOSE(2)
	enddo
	ds=ds-1
	close (unit=2)
	return
	end subroutine  DataS  !(IN)
	end module   DataSeize

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	PROGRAM main
	use FixPrecision
	use DataSeize
	implicit none
	CHARACTER(10)   :: IN
	CHARACTER(100)  :: s
	INTEGER(i8)	    :: I,ND,NPD,nf
	real(R15)       :: xj,xs,xno
	REAL(R15),ALLOCATABLE  :: X(:),Y(:)
	call DataS(IN)
	OPEN(UNIT=8,FILE='error',STATUS='UNKNOWN')
        write(*,*)' '
	write(*,*)'Give Number of fake nodes to be added (0-5 )'
	read(*,*)nf
	write(8,*)'Number of fake nodes added',nf
	ALLOCATE(X(0:DS+2*nf+1),Y(0:DS+2*nf+1))
	ND=DS
	OPEN(UNIT=2,FILE=in,STATUS='UNKNOWN')
	 OPEN(UNIT=3,FILE='ortho',STATUS='UNKNOWN')
	 OPEN(UNIT=4,FILE='mono',STATUS='UNKNOWN')
	if(ic.ne.0)then
   	write(*,*)'# The following',ic,'lines ignored'
 !  	write(3,*)'# The following',ic,'lines ignored'
	do i=1,Ic
	read(2,'(A70)')s
	write(*,'(A70,a)')s,'#Ignore'
!	write(3,'(A70,a)')s,'#Ignored'
    	ENDDO
    	write(*,*)'# --------------------------------------------'
!    	write(3,*)'# --------------------------------------------'
    	endif
	xno=0.
	do i=1,ND
	read(2,*)x(i),y(i),xs
	xno=xs*xs+xno
	enddo
	xno=sqrt(xno)
	close(2)
    	WRITE(*,'(''     Ply order to fit :- '')')
    	WRITE(*,'(''     Give -1 to select the lowest mono-poly order   '')')
    	WRITE(*,'(''     or  '')')
    	WRITE(*,'(''     Give a poly order to fit '')')
	read(*,*)npd
	write(4,*)' # RMS Noise in signal',xno
	write(3,*)' # RMS Noise in signal',xno
	write(*,*)' # RMS Noise in signal',xno
        CALL ortho_OP(nf,x,y,nD,npD)
      	 STOP ;  END

      	 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	SUBROUTINE PARABOLIC_INTRA(X,y,R0,C0)   ! corrected 12/6/23
    	use FixPrecision
    	IMPLICIT NONE
    	REAL(R15)  :: C0
    	REAL(R15)  :: A, B,C,de
    	REAL(R15)  :: X(0:3),y(0:3)
    	REAL(QP)        :: r0

     	de = (x(1)-x(2)) * (x(1)-x(3)) * (x(2)-x(3));
     	A  = (x(3) * (y(2)-y(1)) + x(2) * (y(1)-y(3)) + x(1) * (y(3)-y(2))) / de
     	B  = (x(3)*x(3) * (y(1)-y(2)) + x(2)*x(2) * (y(3)-y(1)) + x(1)*x(1) * (y(2)-y(3))) / de
     	C  = (x(2) * x(3) * (x(2)-x(3)) * y(1)+x(3) * x(1) * (x(3)-x(1)) * y(2)+x(1) * x(2) * (x(1)-x(2)) * y(3)) / de
    	c0=a*r0*r0+b*r0+c  ! working
! 	de = (x1 - x2) * (x1 - x3) * (x2 - x3)
! 	A     = (x3 * (y2 - y1) + x2 * (y1 - y3) + x1 * (y3 - y2)) / de
!	B     = (x3**2 * (y1 - y2) + x2**2 * (y3 - y1) + x1**2 * (y2 - y3)) / de
!	C     = (x2 * x3 * (x2 - x3) * y1 + x3 * x1 * (x3 - x1) * y2 + &
!            x1 * x2 * (x1 - x2) * y3) / de
!	xm = -B / (2.*A)  ! x min
!	ym  = C - B**2 / (4.*A)  ! y min
!	write(*,*)x(1),x(2),x(3),xm
!	write(*,*)y(1),y(2),y(3),ym
    	return
	end
	SUBROUtine  ortho_OP(nf,xt,yt,np,dp)
	 ! working :
   	use FixPrecision
   	use DataSeize
   	IMPLICIT none
        INTEGER(i8), INTENT(IN)      :: np
    	INTEGER (i8)      :: I,J,kk,KL,ii,jj,DP,dps,dpe,SP,sp_s,sp_e,nsp,nf
    	REAL(R15)    :: Xt(0:np+nf*2+1),Yt(0:np+nf*2+1)
        REAL(R15)    :: eor1,em,emr
    	REAL(R15), ALLOCATABLE   :: YN(:)
    	REAL(R15), allocatable    :: eom(:),DER(:),an(:),emm(:)
    	REAL(QP)    :: spf,esi,dpf,T1,bB,Spi,start,es
	REAL(QP), allocatable    :: BN(:),BR(:),a(:),al(:),ga(:),C(:,:),x1(:),x2(:),t(:,:),yc(:),xn(:)  ! ,s(:,:)
    	if(dp==-1)then
    	DPS=NP-2
	else
	dps=DP
	endif
    	allocate(Eom(0:dps+3),emm(0:dps+3),DER(1:Dps+3),an(0:dps+3))  ! ,s(0:dps+3,0:dps+3)
    	allocate(x1(0:dps+3),x2(0:dps+3),a(0:dps+3),al(0:dps+3),ga(0:dps+3))
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 	sp=np
       	start=(int(xt(1)*100.q0))*.01q0
	start=xt(1)
	es=abs(float(int((xt(2)-xt(1))*1000.q0)))*.001q0
	nsp=2+int((xt(sp)-xt(1))/es)+2*nf
 	allocate (xn(0:nsp+1),yn(0:nsp+1),yc(0:nsp+1),t(0:dps+3,0:nsp+1))
	call EQ_FI(nf,sP,start,es,XT,YT,xn,yn,nsp)
!	deallocate (xt,yt)
	sp=nsp
	if(dps.gt.sp-1)dps=sp-1
!	es1=es*1.q0
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! 	calculating ortho poly
	es=.5Q0*es  !1  !  to be restored
    	spf=Dfloat(sp)
    	spi=1.Q0/sPf
    	esi=1.Q0/es
    	bB=-(xn(1)+es*(spF-1.q0))
     	do i=1,sp
    	xn(i)=xn(i)+bB
    	enddo
	A=0.
	eor1=1.e20
	YC=0.
	kk=1
	X1=0.q0
	X2=0.q0
	AL=0.q0
	I=1
	sp_s=1      !
	sp_e=sp
	AL(1)=1./(spi)**.5q0
	t(1,1)=AL(1)
	OPEN(UNIT=7,FILE='error',STATUS='UNKNOWN')
	do while (kk.eq.1)
 	dpf=Dfloat(i)
    	al(i+1)=(esi/dpf)*((4.Q0*DPF*DPF-1.q0)/(SPF*SPF-DPF*DPF))**.5q0
	ga(i+1)=al(i+1)/al(i)
999	continue
	do j=sp_s,sp_e
	if(i.eq.1)then
       	t(1,j)=t(1,1)
    	x1(1)=x1(1)+yn(j)*t(1,j)
    	x2(1)=x2(1)+t(1,j)*t(1,j)
    	goto 8989
    	endif
    	if(i.eq.2)then
       	t(I,J)=al(i)*(xn(j))*t(i-1,j)
    	x1(2)=x1(2)+t(I,j)*yn(j)
    	x2(2)=x2(2)+t(I,j)*t(I,j)
    	goto 8989
 	endif
	t(i,j)=al(i)*xn(j)*t(i-1,j)-ga(i)*t(i-2,j)
	x1(i)=x1(i)+t(i,j)*yn(j)
	x2(i)=x2(i)+t(i,j)*t(i,j)
8989 	continue
	enddo
!	if(abs(x2(i)-1.q0).gt.1.q8)then
!	a(i)=0.
!	else
	A(I)=X1(I)/x2(I)
!	endif
!	if(x2(i).gt..9q4900)then
!	kk=0    ! check overflow
!	write(*,*)'terminated to avoid overflow at',i
!	write(3,*)'terminated to avoid overflow at',i
!	endif
!	WRITE(*,*)'I, A,x1,X2', I,A(I),x1(i),X2(I)
!	IF(ABS(1.D0-X2(i)).GT.(1.D-13)) THEN
!	WRITE(*,*)'ORTHOGONALITY LOST '
!	if(dp.eq.-1)kk=0
!	ENDIF
! SEARCH OPTIMUM OP DEGREE
	Eom(I)=0.
	do ii=1,sp
	yc(ii)=yc(ii)+a(I)*t(I,ii)
       	eom(i)=eom(i)+(yc(ii)-yn(ii))*(yc(ii)-yn(ii)) !
    	enddo
	if(eom(i).Lt.eor1)then
	eor1=eom(i)
	ELSE
	if(dp.eq.-1)then
	do ii=1,sp
	yc(ii)=yc(ii)-a(I)*t(I,ii)
    	enddo
	dpe=i-1
	kk=0
	endif
	endif
	goto 888
	if(dp.ne.-1.and. abs(1.q0-x2(I)).gt.00000001 )then
	t(i,j)=0.
	sp_s=sp_s+1      !
	sp_e=sp_e-1
	write(*,*)'i,s,e,t(i,s),t(i,e),x2(i)',i,sp_s,sp_e,t(i,sp_s),t(i,sp_e),x2(i)   !!!!!!!!!!!!!!!!!!!!
	goto 999
	endif
888	continue
       write(7,*)i,sqrt(eom(i))
	i=i+1
	if(i.gt.dps+1)kk=0
	enddo  ! SCAN OVER DEGREE
	close(unit=7)
	dpe=i-1
	write(3,*)'#####################################################'
	write(*,*)'See the file:-ortho'
	write(*,*)'# Ortho Poly order used and error',DPE-1,sqrt(eom(dpe-1))
	write(3,*)'# Ortho Poly order used and error',DPE-1,sqrt(eom(dpe-1))
	do i=nf+1,sp-nf ; write(3,'(f20.10,5(2X,F20.10))')xn(i)-bb,yn(i),yc(i),YC(I)-YN(I) ; enddo
	deallocate(t,x1,x2)
	allocate(C(-3:Dpe+3,-3:Dpe+3),bn(0:dpe+3),BR(0:DPe+3))
! 	calculating MONO coefficients
	C=0.q0
 	c(0,0) =AL(1)
        c(1,1)=c(0,0)*AL(2)
   	c(1,0)=al(2)*bb*c(0,0)
        DO I=2,DPE
      	do j=0,dpe
	c(i,j)=aL(i+1)*(c(i-1,j-1)+bb*c(i-1,j)-c(i-2,j)/aL(i))
        enddo
        enddo
!	BN(J)=BN(J)+C(I,J)*A(I+1)
!	DO I=0,DPE ;  WRITE(*,'((1010(i3,D15.5)))')(j,C(I,J), J=0,I) ; ENDDO
!	write(*,*)' '
!	DO I=0,DPE ;  WRITE(3,'((1010(2X,D15.5)))')(j,C(I,J), J=0,I) ; ENDDO
	dpe=dpe-1
	emr=1.d30
	do kl=0, dpe
	DO J=0,kl
	BN(j)=0.q0
	DO I=J,kl
	BN(J)=BN(J)+C(I,J)*a(i+1)
	ENDDO
	ENDDO
	!WRITE(*,*)'B-----------'
 ! 	WRITE(*,'(10(10(i3,E15.5)))')(i,BN(I),I=0,KL)
!!!!!!!!!!!!!!!!!!!!!!!!
 		em=0.
 		do i=1,sp
      		 t1 = bn(kl)*(Xn(i)-Bb) !!!!!!!!!!!!!!!!!!!!!!!!!
  		do j=kl-1, 1, -1
  	  	t1 = (bn(j)+t1)*(Xn(i)-Bb)  !!!!!!!!!!!!!!!!!!!!!!!!
  		end do
  		t1 = t1+bn(0)
		yc(i)=t1      		!HORNER algoritham for polynomials.
	   	em=em+(yc(i)-yn(i))*(yc(i)-yn(i))
 	   	enddo
 !	   	write(*,*)'poly order & error ',kl,sqrt(em)

		br=bn
		jj=kl
! 		if(dp.eq.-1) then
	    	if(em.lt.emr)then
	    	br=0.
	    	br=bn
	    	emr=em
	    	jj=kl
	    	else
!	    	jj=kl-1  !!!!!!!!!!!!!!!!!!!!!
	     	exit
	    	endif
!	    	endif
	    	enddo
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 	   	do i=1,np
      		t1 = br(kl)*(Xt(i)) !!!!!!!!!!!!!!!!!!!!!!!!!
  		do j=kl-1, 1, -1
  	  	t1 = (br(j)+t1)*(Xt(i))  !!!!!!!!!!!!!!!!!!!!!!!!
  		end do
  		t1 = t1+br(0)
		yc(i)=t1      		
 	   	enddo
 !	   	write(*,*)'poly order & error ',kl,em
    	WRITE(*,*)'******************************************************* '
	write(*,*)'------------------'
	write(*,*)'See the file:-mono'
	write(*,*)'#  Poly order & error',KL,sqrt(em)
  	write(*,*)'# Degree & Poly Coefficients '
	kk=(kl-1)/5  !*5
	do i=0, kk-1
	jj=i*5
	WRITE(*,'(5(i3,2X,e30.20,5x))')(j+jj,Br(j+jj),j=0,4)
	enddo
	if((kk-1)*5.ne.(kl-1))WRITE(*,'(5(i3,2X,e30.20,5x))')(j,Br(j),j=(kk*5),kl-1)
	WRITE(*,*)'------------------'
	write(4,*)'#  Poly order & error',KL,sqrt(em)
    	do i=1,np ; write(4,'(5(2X,F20.5))')Xt(I), yt(i),yc(i),Yt(I)-YC(I) ; enddo
    	write(4,*)' '
    	write(4,*)'# Degree & Poly Coefficients '
    	WRITE(4,*)'****************************************************** '
    	do i=0, kk-1
	jj=i*5
	WRITE(4,'(5(i3,2X,e30.20,5x))')(j+jj,Br(j+jj),j=0,4)
	enddo
	if((kk-1)*5.ne.(kl-1))WRITE(4,'(5(i3,2X,e30.20,5x))')(j,Br(j),j=(kk*5),kl-1)
    	WRITE(4,*)'****************************************************** '

! Binomial coefficients
!	S=0.
!	s(0,0)=1.
!	s(1,0)=1.
!	s(1,1)=1.
!	do i=1,dpe
!	do j=1,I-1
!	s(i,j)= (s(i-1,j-1)+s(i-1,j))
!	enddo
!	s(i,i)=1.
!	s(i,0)=1.
!	enddo
!	do i=0,dpe
!	do j=0,i
!	s(i,j)= s(i,j)*(-bb)**(j)
!	VALID FOR DPE<123
!	enddo
!	enddo
!	s(0,0)=1.q0
!	WRITE(*,*)'S---------------'
!	DO I=0,DPE ; DO J=0,I ; WRITE(*,*)I,J,(s(I,J)) ; ENDDO ; ENDDO
! 	DO I=0,DPE ; DO J=0,I ; WRITE(3,*)I,J,(s(I,J)) ; ENDDO ; ENDDO
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!	   T1=1.q0
! 	   YC(I)=BN(0)
! 	   DO J=1,kl
! 	   T1=T1*(XN(I)-BB)
! 	   YC(I)=YC(I)+BN(J)*T1
! 	   enddo
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

   	stop
    	end


	SUBROUTINE EQ_FI(nf,NP,start,step_es,XT,YT,xn,yn,nsp)
    	use FixPrecision !
    	use DataSeize
    	IMPLICIT none
    	INTEGER(i2)        :: bv
    	INTEGER(i8)        :: NP,NPN,I,KL,KS,L,L2,k,nsp,kk,nf
    	REAL(R15)       :: yT(0:np+nf*2+1),xT(0:np+nf*2+1),sl,sl1,sh,sh1
    	REAL(R15)       :: x1(0:3),y1(0:3),y2(0:12),YR
    	REAL(R15)       :: s_noise
    	REAL(R15)       :: YN(0:NsP+1),yn1(0:NsP+1) ! define dimension
	REAL(qp)        :: XN(0:NsP+1)
	REAL(QP)        :: start,step_es,x_e,c1,c2
	k=1
	if(start.le. xt(1))then
     	start=xt(1)*1.q0
     	xn(nf+1)=xt(1)
     	yn(nf+1)=yt(1)
     	else
   	k=1
110     if(start.gt.xt(k))then
    	K=K+1
    	goto 110
     	ENDIF
     	xn(nf+1)=XT(k)
     	YN(nf+1)=YT(k)
     	endif
!     	write(*,*)'k,start',k,start
!    	do l=0,6 ; write(*,*)'k,xt(k),yt(k)',k+l,xt(k+l),yt(k+l) ; enddo
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	kk=int((xt(np)-xt(1))/step_es)
!	write(*,*)'kk',kk
	i=1
	kl=1+nf
	xn(1)=start
	yn(1)=yt(1)
	do l =2,(kk)
	kl=kl+1
	xn(kl)=xn(kl-1)+step_es
	i=i+1
1	c1=xn(kl)-xt(i)
	c2=c1/10.d0
	if(c1.gt.(xt(i)-xt(i-1)+c2))then
	i=i+1
	goto 1
	endif
2	c2=xn(kl)-xt(i+1)
	if(abs(c2).le.abs(c1))then
	c1=c2
	i=i+1
	goto 2
	else
	i=i-1
	endif
				x1(1)=xt(i)
   				y1(1)=yt(i)
   				x1(2)=xt(i+1)
   				y1(2)=yt(i+1)
   				x1(3)=xt(I+2)
   				y1(3)=yt(i+2)
   	x_e=xn(kl)
 	CALL PARABOLIC_INTRA(X1,y1,x_e,Yr)
 	yn(kl)=YR
! 	write(*,*)'i,xt,yt,            ',i,xt(i),yt(i)
!   	write(*,*)'i,xt,yt,kl, xn,yn   ',i+1,xt(i+1),yt(i+1),kl,xn(kl),yn(kl)
 !  	write(*,*)'i,xt,yt             ',i+2,xt(i+2),yt(i+2)
!	write(*,*)'______'
	enddo
	kl=kl+1
	xn(kl)=xn(kl-1)+step_es
	yn(kl)=yt(np)
!	write(*,*)'kl,XN,YN                              ',kl,XN(kl),yn(kl)
!       write(*,*)'kl',kl
	if(nf.ne.0)then
 	write(*,*)'Give choice of boundary condition'
  	write(*,*)'Give zero for best fit to op'
  	write(*,*)'Give 1 for best fit to monomial'
!  	write(*,*)'Give 2 for a graded decrease to zero at the boundary'
  	read(*,*)bv
	if(bv.ne.0)then
	 write(8,*)'gives correct mono (op converges fast but may diverge at higher polynomial digrees)'
 	else
	write(8,*)'gives non diverging, but slower converging, op'
	endif
	if(bv.eq.2)then
	sl1=yt(1)  !+sl
	sl=sl1/float(nf)
!	write(*,*)'sl',sl
	sh1=yt(np)   !+sh
	sh=sh1/float(nf)
!	write(*,*)'sh@@',sh
	endif
	do i=1,nf
	xn(nf+1-i)=xn(nf+2-i)-step_es
	if(bv.eq.0)yn(nf+1-i)=0.
	if(bv.eq.1)yn(nf+1-i)= yt(1)
		if(bv.eq.2)then
		sl1=sl1-sl
		if(sl1.lt.0.)sl1=0
		!write(*,*)'sl1',yt(1),sl1
		yn(nf+1-i)= sl1
		endif
		kl=kl+1
		xn(kl)=xn(kl-1)+step_es
		if(bv.eq.0)yn(kl)=0.
 		if(bv.eq.1) yn(kl)= yt(np)
 		 if(bv.eq.2)then
		sh1=sh1-sh
		if(sh1.lt.0.)sh1=0
		yn(kl)= sh1
		!write(*,*)'sh1',yt(np),yn(kl)
		endif
!	write(*,*)kl,xn(kl),yn(kl)
	enddo
	endif
 	npn=kl
 	NSP=NPN
	RETURN     ! 
	END

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



